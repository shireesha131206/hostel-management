
const ROOMS_API = "http://localhost:8080/api/rooms";

async function loadAvailableRooms() {
    const savedUser = sessionStorage.getItem("hostelUser");

    if (!savedUser) {
        window.location.replace("index.html");
        return;
    }

    let user;

    try {
        user = JSON.parse(savedUser);
    } catch (error) {
        sessionStorage.removeItem("hostelUser");
        window.location.replace("index.html");
        return;
    }

    const roomContainer = document.getElementById("availableRooms");

    if (!roomContainer) {
        console.error("Room display element was not found in student-dashboard.html");
        return;
    }

    roomContainer.innerHTML = `
        <div class="text-center py-4">
            <div class="spinner-border text-success" role="status"></div>
            <p class="small-muted mt-2">Loading rooms from the database...</p>
        </div>
    `;

    try {
        const response = await fetch(`${ROOMS_API}/available`, {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${user.token}`,
                "Accept": "application/json"
            }
        });

        if (response.status === 401 || response.status === 403) {
            roomContainer.innerHTML = `
                <p class="text-danger small">
                    Your session cannot access room information.
                    Please log in again or check backend permissions.
                </p>
            `;
            return;
        }

        if (!response.ok) {
            throw new Error(`Server returned status ${response.status}`);
        }

        const rooms = await response.json();

        if (!Array.isArray(rooms) || rooms.length === 0) {
            roomContainer.innerHTML = `
                <div class="room-placeholder">
                    <i class="bi bi-door-closed"></i>
                    <h3>No available rooms</h3>
                    <p>There are currently no rooms with available beds.</p>
                </div>
            `;
            return;
        }

        roomContainer.innerHTML = `
            <div class="row g-3">
                ${rooms.map(room => `
                    <div class="col-12 col-md-6">
                        <div class="border rounded-4 p-3 h-100">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="fw-bold">Room ${escapeRoomText(room.roomNumber)}</span>
                                <span class="badge text-bg-success">Available</span>
                            </div>
                            <div class="small text-secondary mb-2">
                                Capacity: ${Number(room.capacity)}
                            </div>
                            <div class="small text-secondary mb-2">
                                Occupied beds: ${Number(room.occupied)}
                            </div>
                            <div class="small text-secondary mb-3">
                                Available beds: ${Number(room.availableBeds)}
                            </div>
                            <div class="fw-bold text-success">
                                ₹${Number(room.rentPerPerson).toLocaleString("en-IN")}
                                <span class="small text-secondary fw-normal">/ person</span>
                            </div>
                        </div>
                    </div>
                `).join("")}
            </div>
        `;
    } catch (error) {
        console.error("Could not load rooms:", error);

        roomContainer.innerHTML = `
            <div class="alert alert-warning mb-0">
                <strong>Couldn't load room information.</strong>
                <p class="small mb-0 mt-1">
                    Check that the Spring Boot backend is running and the
                    room API is accessible. Open the browser console for details.
                </p>
            </div>
        `;
    }
}

function escapeRoomText(value) {
    const element = document.createElement("span");
    element.textContent = String(value ?? "");
    return element.innerHTML;
}

document.addEventListener("DOMContentLoaded", loadAvailableRooms);

