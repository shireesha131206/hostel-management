
package com.hostel.hostel_management.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hostel.hostel_management.entity.Role;
import com.hostel.hostel_management.entity.User;
import com.hostel.hostel_management.repository.UserRepository;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // Public signup creates HOSTELER accounts only.
    public User registerUser(
            String fullName,
            String email,
            String rawPassword) {

        if (userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException(
                    "Email is already registered");
        }

        User user = new User();
        user.setFullName(fullName);
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(rawPassword));
        user.setRole(Role.HOSTELER);

        return userRepository.save(user);
    }

    // WARDEN creation must be restricted to an authorized process.
    public User registerOwner(
            String fullName,
            String email,
            String rawPassword) {

        if (userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException(
                    "Email is already registered");
        }

        User user = new User();
        user.setFullName(fullName);
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(rawPassword));
        user.setRole(Role.WARDEN);

        return userRepository.save(user);
    }
}
