
package com.hostel.hostel_management.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.hostel.hostel_management.entity.Room;
import com.hostel.hostel_management.entity.User;
import com.hostel.hostel_management.repository.UserRepository;

@RestController
@RequestMapping("/api/hostellers")
public class HostellerController {

    private final UserRepository userRepository;

    public HostellerController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // WARDEN / ADMIN: View all hostellers.
    @GetMapping
    @PreAuthorize("hasAnyRole('WARDEN', 'ADMIN')")
    public ResponseEntity<List<Map<String, Object>>> getAllHostellers() {

        List<Map<String, Object>> hostellers = new ArrayList<>();

        for (User user : userRepository.findAll()) {

            if (!"HOSTELER".equals(user.getRole().name())) {
                continue;
            }

            Map<String, Object> details = new HashMap<>();

            details.put("id", user.getId());
            details.put("fullName", user.getFullName());
            details.put("email", user.getEmail());
            details.put("role", user.getRole().name());
            details.put(
                    "roomNumber",
                    user.getRoom() != null
                            ? user.getRoom().getRoomNumber()
                            : "Not Assigned"
            );

            hostellers.add(details);
        }

        return ResponseEntity.ok(hostellers);
    }

    // HOSTELER: View their own profile.
    @GetMapping("/me")
    @PreAuthorize("hasRole('HOSTELER')")
    public ResponseEntity<Map<String, Object>> getMyProfile(
            Authentication authentication) {

        User user = getHosteller(authentication);

        Map<String, Object> profile = new HashMap<>();

        profile.put("id", user.getId());
        profile.put("fullName", user.getFullName());
        profile.put("email", user.getEmail());
        profile.put("role", user.getRole().name());
        profile.put(
                "roomNumber",
                user.getRoom() != null
                        ? user.getRoom().getRoomNumber()
                        : "Not Assigned"
        );

        return ResponseEntity.ok(profile);
    }

    // HOSTELER: View their assigned room.
    @GetMapping("/my-room")
    @PreAuthorize("hasRole('HOSTELER')")
    public ResponseEntity<Map<String, Object>> getMyRoom(
            Authentication authentication) {

        User user = getHosteller(authentication);

        Map<String, Object> details = new HashMap<>();

        if (user.getRoom() == null) {
            details.put(
                    "message",
                    "You have not been assigned a room yet."
            );

            return ResponseEntity.ok(details);
        }

        Room room = user.getRoom();

        details.put("roomNumber", room.getRoomNumber());
        details.put("capacity", room.getCapacity());
        details.put("occupied", room.getOccupied());
        details.put("availableBeds", room.getAvailableBeds());
        details.put("rentPerPerson", room.getRentPerPerson());
        details.put("status", room.getStatus());

        return ResponseEntity.ok(details);
    }

    private User getHosteller(Authentication authentication) {

        if (authentication == null
                || authentication.getName() == null) {

            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Please log in again."
            );
        }

        User user = userRepository.findByEmail(
                authentication.getName()
        ).orElseThrow(() ->
                new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Logged-in user was not found."
                ));

        if (!"HOSTELER".equals(user.getRole().name())) {
            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "This endpoint is only available to hostelers."
            );
        }

        return user;
    }
}
