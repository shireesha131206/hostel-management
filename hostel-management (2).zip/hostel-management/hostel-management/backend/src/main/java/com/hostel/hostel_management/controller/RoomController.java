
package com.hostel.hostel_management.controller;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.hostel.hostel_management.dto.RoomAssignmentRequest;
import com.hostel.hostel_management.entity.Room;
import com.hostel.hostel_management.entity.User;
import com.hostel.hostel_management.service.RoomService;

@RestController
@RequestMapping("/api/rooms")
public class RoomController {

    private final RoomService roomService;

    public RoomController(RoomService roomService) {
        this.roomService = roomService;
    }

    @GetMapping
    public List<Room> getAllRooms() {
        return roomService.getAllRooms();
    }

    @GetMapping("/available")
    public List<Room> getAvailableRooms() {
        return roomService.getAvailableRooms();
    }
    
@PutMapping("/assign")
@PreAuthorize("hasAnyRole('WARDEN', 'ADMIN')")
public Map<String, Object> assignHostellerToRoom(
        @RequestBody RoomAssignmentRequest request) {

    try {
        User hosteller = roomService.assignHostellerToRoom(
                request.getHostellerId(),
                request.getRoomId());

        return Map.of(
                "message", "Hosteller assigned to room successfully.",
                "hostellerId", hosteller.getId(),
                "hostellerName", hosteller.getFullName(),
                "roomId", hosteller.getRoom().getId(),
                "roomNumber", hosteller.getRoom().getRoomNumber()
        );

    } catch (IllegalArgumentException exception) {
        throw new ResponseStatusException(
                HttpStatus.BAD_REQUEST,
                exception.getMessage());
    }
}


    @PostMapping
    public Room addRoom(@RequestBody RoomRequest request) {
        try {
            return roomService.addRoom(
                    request.getRoomNumber(),
                    request.getCapacity(),
                    request.getRentPerPerson());
        } catch (IllegalArgumentException exception) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    exception.getMessage());
        }
    }

    public static class RoomRequest {

        private String roomNumber;
        private int capacity;
        private BigDecimal rentPerPerson;

        public RoomRequest() {
        }

        public String getRoomNumber() {
            return roomNumber;
        }

        public void setRoomNumber(String roomNumber) {
            this.roomNumber = roomNumber;
        }

        public int getCapacity() {
            return capacity;
        }

        public void setCapacity(int capacity) {
            this.capacity = capacity;
        }

        public BigDecimal getRentPerPerson() {
            return rentPerPerson;
        }

        public void setRentPerPerson(BigDecimal rentPerPerson) {
            this.rentPerPerson = rentPerPerson;
        }
    }
    
@PutMapping("/reassign/{hostellerId}/{newRoomId}")
@PreAuthorize("hasAnyRole('WARDEN', 'ADMIN')")
public Map<String, Object> reassignHosteller(
        @PathVariable Long hostellerId,
        @PathVariable Long newRoomId) {

    try {
        User hosteller = roomService.reassignHostellerToRoom(
                hostellerId, newRoomId);

        return Map.of(
                "message", "Room changed successfully.",
                "hostellerId", hosteller.getId(),
                "hostellerName", hosteller.getFullName(),
                "roomId", hosteller.getRoom().getId(),
                "roomNumber", hosteller.getRoom().getRoomNumber()
        );

    } catch (IllegalArgumentException exception) {
        throw new ResponseStatusException(
                HttpStatus.BAD_REQUEST,
                exception.getMessage());
    }
}

}
