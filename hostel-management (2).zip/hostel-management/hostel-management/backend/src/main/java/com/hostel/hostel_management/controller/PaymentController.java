
package com.hostel.hostel_management.controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.hostel.hostel_management.entity.Payment;
import com.hostel.hostel_management.service.PaymentService;

@RestController
@RequestMapping("/api/payments")
@PreAuthorize("hasAnyRole('WARDEN', 'ADMIN')")
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping
    public Payment recordPayment(@RequestBody PaymentRequest request) {
        try {
            return paymentService.recordPayment(
                    request.getHostellerId(),
                    request.getYear(),
                    request.getMonth(),
                    request.getAmount(),
                    request.getPaymentMethod(),
                    request.getNote());
        } catch (IllegalArgumentException exception) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, exception.getMessage());
        }
    }

    @GetMapping
    public List<Payment> getAllPayments() {
        return paymentService.getAllPayments();
    }

    @GetMapping("/hosteller/{hostellerId}")
    public List<Payment> getHostellerPayments(
            @PathVariable Long hostellerId) {
        return paymentService.getHostellerPayments(hostellerId);
    }

    @GetMapping("/monthly")
    public List<Payment> getMonthlyPayments(
            @RequestParam int year,
            @RequestParam int month) {
        try {
            return paymentService.getMonthlyPayments(year, month);
        } catch (IllegalArgumentException exception) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, exception.getMessage());
        }
    }

    public static class PaymentRequest {
        private Long hostellerId;
        private int year;
        private int month;
        private BigDecimal amount;
        private String paymentMethod;
        private String note;

        public PaymentRequest() {}

        public Long getHostellerId() { return hostellerId; }
        public void setHostellerId(Long hostellerId) { this.hostellerId = hostellerId; }

        public int getYear() { return year; }
        public void setYear(int year) { this.year = year; }

        public int getMonth() { return month; }
        public void setMonth(int month) { this.month = month; }

        public BigDecimal getAmount() { return amount; }
        public void setAmount(BigDecimal amount) { this.amount = amount; }

        public String getPaymentMethod() { return paymentMethod; }
        public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

        public String getNote() { return note; }
        public void setNote(String note) { this.note = note; }
    }
}
